package com.example.test2akash;

public class Parent {
}

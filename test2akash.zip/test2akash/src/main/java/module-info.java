module com.example.test2akash {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.test2akash to javafx.fxml;
    exports com.example.test2akash;
}